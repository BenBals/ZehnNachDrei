(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['fourseven:scss'] = {};

})();

//# sourceMappingURL=fourseven_scss.js.map
