(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// coffee/server/server.coffee.js                                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var options;                                                           // 4
                                                                       //
Meteor.publish('articles', function() {                                // 4
  if (Roles.userIsInRole(this.userId, ['admin', 'editor'])) {          // 6
    return Articles.find({}, {                                         //
      sort: {                                                          // 8
        publishDate: -1                                                // 9
      }                                                                //
    });                                                                //
  } else {                                                             //
    return Articles.find({                                             //
      publishDate: {                                                   // 15
        $lt: Date.now()                                                // 16
      },                                                               //
      title: {                                                         // 15
        $ne: ""                                                        // 19
      },                                                               //
      description: {                                                   // 15
        $ne: ""                                                        // 20
      },                                                               //
      text: {                                                          // 15
        $ne: ""                                                        // 21
      },                                                               //
      imgSource: {                                                     // 15
        $ne: ""                                                        // 22
      }                                                                //
    }, {                                                               //
      sort: {                                                          // 24
        publishDate: -1                                                // 25
      }                                                                //
    });                                                                //
  }                                                                    //
});                                                                    // 4
                                                                       //
Meteor.publish('userData', function() {                                // 4
  if (Roles.userIsInRole(this.userId, ['admin'])) {                    // 32
    return Meteor.users.find({});                                      // 33
  } else {                                                             //
    return Meteor.users.find({                                         // 35
      _id: this.userId                                                 // 35
    });                                                                //
  }                                                                    //
});                                                                    // 31
                                                                       //
if (Meteor.users.find().count() === 0) {                               // 38
  options = {                                                          // 39
    email: 'benjustusbals@gmail.com',                                  // 40
    password: 'pass',                                                  // 40
    roles: ['admin', 'editor']                                         // 40
  };                                                                   //
  Accounts.createUser(options);                                        // 39
}                                                                      //
                                                                       //
Roles.setUserRoles(Meteor.users.findOne()._id, ['admin', 'editor']);   // 4
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.coffee.js.map
