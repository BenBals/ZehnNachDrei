(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['wolves:bourbon'] = {};

})();

//# sourceMappingURL=wolves_bourbon.js.map
